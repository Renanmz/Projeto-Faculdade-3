package com.api.Agro.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.api.Agro.model.OcorrenciaModel;

public interface OcorrenciaRepository extends JpaRepository<OcorrenciaModel, Long>  {

}
